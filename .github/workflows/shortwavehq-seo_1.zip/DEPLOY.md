# ShortwaveHQ SEO deploy bundle

Extract everything into the **root of your GitHub repo** (same folder as your
current index.html). Final layout:

    index.html                        (overwrites yours — has all SEO fixes)
    build.js                          static-page generator
    netlify.toml                      tells Netlify to run build.js -> publish dist/
    og-image.png                      social/share image (already referenced)
    data/live.json, data/daily.json   your existing files — leave in place
    .github/workflows/daily-rebuild.yml

## What each file gives you
- index.html      : 1 H1 + real headings, canonical/robots/OG/Twitter tags,
                    WebSite+SearchAction / Organization / FAQPage schema,
                    visible FAQ block, ?q= search handler.
- build.js        : generates ~330 crawlable pages (per station, per frequency,
                    A-Z indexes) + sitemap.xml + robots.txt into dist/.
- netlify.toml    : build command = node build.js, publish = dist.
- daily-rebuild   : cron that pings a Netlify build hook so the site rebuilds
                    daily even with no commit.

## Deploy steps
1. Drop these files into repo root. Confirm data/ and og-image.png are at root.
2. Commit + push. If Netlify is Git-connected it auto-builds and publishes dist/.
3. Build hook (for daily-rebuild.yml):
   Netlify > Site config > Build & deploy > Build hooks > add hook, copy URL.
   GitHub > repo Settings > Secrets and variables > Actions >
   new secret NETLIFY_BUILD_HOOK = that URL.
4. Google Search Console: add property, submit
   https://hqshortwaveradio.com/sitemap.xml , run Rich Results Test on a
   station page and the homepage FAQ.

## Freshness model
- Daily live data (on-air-now, conditions, SOTD): data/*.json, fetched with
  cache:no-store -> fresh per visit. Keep update.py committing these.
- Schedule pages: evergreen, rebuilt when SCH changes; lastmod = last commit
  date of index.html (honest). Homepage lastmod = today.

## If your canonical domain is NOT hqshortwaveradio.com
Change SITE at the top of build.js AND the URLs in index.html
(canonical, og:url, twitter:image, og:image, JSON-LD urls).

## Safe rollout
Push index.html alone first, verify the live site. Then push build.js +
netlify.toml together so any build issue is isolated to that commit
(watch Netlify > Deploys > build log).

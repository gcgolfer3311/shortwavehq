#!/usr/bin/env node
/* ShortwaveHQ static page generator — SEO landing pages from the SCH database.
   No dependencies. Run: node build.js
   Reads ./index.html, writes everything to ./dist (Netlify publish dir).
   Output: dist/index.html (+assets), dist/station/*, dist/frequency/*,
           dist/stations/, dist/frequencies/, dist/sitemap.xml, dist/robots.txt */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SITE = 'https://hqshortwaveradio.com';   // <-- canonical origin
const SRC  = path.join(__dirname, 'index.html');
const OUT  = path.join(__dirname, 'dist');

const today = new Date().toISOString().slice(0,10);

// "Schedule verified" date = last time the SCH source (index.html) actually
// changed. Honest lastmod for evergreen schedule pages — not the build date.
function lastCommitDate(file){
  try { return execSync(`git log -1 --format=%cs -- "${file}"`,{stdio:['ignore','pipe','ignore']}).toString().trim() || today; }
  catch { return today; }
}
const SCHED_DATE = lastCommitDate('index.html');

// Daily live-data timestamp, if data/daily.json exposes one.
function dailyDate(){
  try {
    const d = JSON.parse(fs.readFileSync(path.join(__dirname,'data','daily.json'),'utf8'));
    const t = d.updated || d.date || d.generated || d.lastUpdated || d.timestamp;
    if (t) return new Date(t).toISOString().slice(0,10);
  } catch {}
  return today;
}
const LIVE_DATE = dailyDate();

// ── read source + extract the SCH array ───────────────────────────
const html = fs.readFileSync(SRC, 'utf8');
const m = html.match(/var\s+SCH\s*=\s*(\[[\s\S]*?\]);/);
if (!m) { console.error('Could not find "var SCH=[...]" in index.html'); process.exit(1); }
let SCH;
try { SCH = Function('"use strict";return (' + m[1] + ')')(); }
catch (e) { console.error('Failed to parse SCH:', e.message); process.exit(1); }
console.log(`Parsed ${SCH.length} schedule rows.`);

// ── helpers ───────────────────────────────────────────────────────
const esc = s => String(s == null ? '' : s)
  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
  .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const slug = s => String(s).toLowerCase().trim()
  .replace(/[^\w\s-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
const khz = f => Math.round(parseFloat(f) * 1000);       // "9.395" -> 9395
const utc = min => { const h=Math.floor(min/60)%24, mm=min%60;
  return String(h).padStart(2,'0')+':'+String(mm).padStart(2,'0'); };
const timeStr = r => (r.s===0 && r.e>=1440) ? '24h' : `${utc(r.s)}–${utc(r.e)} UTC`;
const mkdir = d => fs.mkdirSync(d, { recursive: true });
const write = (rel, body) => { const p=path.join(OUT,rel); mkdir(path.dirname(p)); fs.writeFileSync(p, body); };

// shared minimal branded shell (self-contained, no external CSS)
const CSS = `*{box-sizing:border-box;margin:0;padding:0}
body{background:#f5f0e8;color:#0a0b0e;font-family:Georgia,"Libre Baskerville",serif;line-height:1.6;font-size:17px}
.bar{background:#0a0b0e;border-bottom:3px solid #c0392b;padding:.7rem 1.2rem}
.bar a{color:#fff;text-decoration:none;font-family:system-ui,sans-serif;font-weight:900;letter-spacing:-.03em;font-size:1.15rem}
.bar a em{color:#e74c3c;font-style:normal}
.wrap{max-width:820px;margin:0 auto;padding:1.8rem 1.2rem 3rem}
h1{font-family:system-ui,sans-serif;font-weight:900;letter-spacing:-.03em;font-size:clamp(1.5rem,4vw,2.3rem);line-height:1.1;margin-bottom:.4rem}
.sub{color:#6b5f52;font-size:.95rem;margin-bottom:1.4rem}
table{width:100%;border-collapse:collapse;font-size:.9rem;margin:1rem 0}
th,td{text-align:left;padding:.5rem .6rem;border-bottom:1px solid #d8d0c0}
th{font-family:system-ui,sans-serif;font-size:.7rem;text-transform:uppercase;letter-spacing:.08em;color:#9c8e81}
td a{color:#1a5276}
.cta{display:inline-block;margin:1rem 0;background:#c0392b;color:#fff;text-decoration:none;font-family:system-ui,sans-serif;font-weight:700;padding:.6rem 1.1rem;border-radius:4px;font-size:.9rem}
.links{margin-top:1.4rem;font-size:.85rem}.links a{color:#1a5276;margin-right:1rem;display:inline-block}
.foot{border-top:1px solid #d8d0c0;margin-top:2rem;padding-top:1rem;color:#9c8e81;font-size:.78rem}`;

function page({ title, desc, canonical, h1, sub, jsonld, main }) {
  return `<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${canonical}">
<meta name="robots" content="index,follow,max-image-preview:large">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}">
<meta property="og:type" content="website"><meta property="og:url" content="${canonical}">
<meta property="og:image" content="${SITE}/og-image.png">
${jsonld ? `<script type="application/ld+json">${jsonld}</script>` : ''}
<style>${CSS}</style></head><body>
<div class="bar"><a href="/">Shortwave<em>HQ</em></a></div>
<div class="wrap"><h1>${h1}</h1><div class="sub">${sub}</div>
${main}
<div class="foot">Schedule source: EIBI A-26 · verified ${SCHED_DATE} · <a href="/" style="color:#1a5276">ShortwaveHQ home</a></div>
</div></body></html>`;
}

// ── group data ────────────────────────────────────────────────────
const byStation = new Map(), byFreq = new Map();
for (const r of SCH) {
  if (!r || !r.stn || !r.freq) continue;
  (byStation.get(r.stn) || byStation.set(r.stn, []).get(r.stn)).push(r);
  const k = khz(r.freq);
  (byFreq.get(k) || byFreq.set(k, []).get(k)).push(r);
}

// ── clean/prime dist ──────────────────────────────────────────────
if (fs.existsSync(OUT)) fs.rmSync(OUT, { recursive: true, force: true });
mkdir(OUT);
// copy index.html + any sibling assets (og-image, data/, etc.)
for (const f of fs.readdirSync(__dirname)) {
  if (['build.js','netlify.toml','dist','node_modules','.git'].includes(f)) continue;
  const src = path.join(__dirname, f), dst = path.join(OUT, f);
  fs.cpSync(src, dst, { recursive: true });
}

const urls = ['/'];

// ── station pages ─────────────────────────────────────────────────
const stationIndex = [];
for (const [stn, rows] of byStation) {
  const sl = slug(stn); if (!sl) continue;
  const url = `/station/${sl}/`;
  urls.push(url); stationIndex.push({ stn, sl, count: rows.length });
  const langs = [...new Set(rows.map(r => r.lang).filter(Boolean))];
  const freqs = [...new Set(rows.map(r => khz(r.freq)))].sort((a,b)=>a-b);
  const region = rows[0].reg || rows[0].tgt || '';
  const rowsHtml = rows.slice().sort((a,b)=>khz(a.freq)-khz(b.freq)).map(r =>
    `<tr><td><a href="/frequency/${khz(r.freq)}/">${khz(r.freq)} kHz</a></td><td>${esc(r.lang)}</td><td>${timeStr(r)}</td><td>${esc(r.tgt||'')}</td></tr>`).join('');
  const desc = `${stn} shortwave radio schedule and frequencies: ${freqs.slice(0,6).map(f=>f+' kHz').join(', ')}. Broadcast times (UTC), languages, and target regions. Listen live via WebSDR.`;
  const jsonld = JSON.stringify({
    '@context':'https://schema.org','@type':'BroadcastService','name':stn,
    'broadcastDisplayName':stn,'inLanguage':langs,
    'areaServed':region,'url':SITE+url,'dateModified':SCHED_DATE,
    'broadcaster':{'@type':'Organization','name':stn},
    'broadcastFrequency':freqs.map(f=>({'@type':'BroadcastFrequencySpecification','broadcastFrequencyValue':f,'broadcastSignalModulation':'AM'}))
  });
  write(path.join('station', sl, 'index.html'), page({
    title: `${stn} — Shortwave Frequencies & Schedule (2026) | ShortwaveHQ`,
    desc, canonical: SITE+url,
    h1: `${esc(stn)} Shortwave Schedule`,
    sub: `${freqs.length} frequenc${freqs.length===1?'y':'ies'} · ${langs.join(', ')||'various'} · ${esc(region)}`,
    jsonld,
    main: `<a class="cta" href="/?q=${encodeURIComponent(stn)}">See ${esc(stn)} live on ShortwaveHQ →</a>
<table><thead><tr><th>Frequency</th><th>Language</th><th>Time</th><th>Target</th></tr></thead><tbody>${rowsHtml}</tbody></table>
<div class="links"><strong>Frequencies:</strong> ${freqs.map(f=>`<a href="/frequency/${f}/">${f} kHz</a>`).join(' ')}</div>`
  }));
}

// ── frequency pages ───────────────────────────────────────────────
for (const [k, rows] of byFreq) {
  const url = `/frequency/${k}/`; urls.push(url);
  const stns = [...new Set(rows.map(r => r.stn))];
  const rowsHtml = rows.slice().sort((a,b)=>a.s-b.s).map(r =>
    `<tr><td><a href="/station/${slug(r.stn)}/">${esc(r.stn)}</a></td><td>${esc(r.lang)}</td><td>${timeStr(r)}</td><td>${esc(r.tgt||'')}</td></tr>`).join('');
  const desc = `Who broadcasts on ${k} kHz shortwave? ${stns.slice(0,4).join(', ')}${stns.length>4?' and more':''}. Full schedule with UTC times, languages, and target regions.`;
  write(path.join('frequency', String(k), 'index.html'), page({
    title: `${k} kHz Shortwave — What's On This Frequency | ShortwaveHQ`,
    desc, canonical: SITE+url,
    h1: `${k} kHz Shortwave`,
    sub: `${stns.length} station${stns.length===1?'':'s'} logged on this frequency`,
    jsonld: null,
    main: `<a class="cta" href="/?q=${k}">Check ${k} kHz live on ShortwaveHQ →</a>
<table><thead><tr><th>Station</th><th>Language</th><th>Time</th><th>Target</th></tr></thead><tbody>${rowsHtml}</tbody></table>`
  }));
}

// ── HTML index pages (crawl paths + internal linking) ─────────────
stationIndex.sort((a,b)=>a.stn.localeCompare(b.stn));
write('stations/index.html', page({
  title: 'All Shortwave Stations A–Z | ShortwaveHQ',
  desc: `Complete A–Z directory of ${stationIndex.length} shortwave radio stations with frequencies, schedules, and languages.`,
  canonical: `${SITE}/stations/`, h1: 'All Shortwave Stations A–Z',
  sub: `${stationIndex.length} stations in the EIBI A-26 database`, jsonld: null,
  main: `<div class="links">${stationIndex.map(s=>`<a href="/station/${s.sl}/">${esc(s.stn)}</a>`).join('')}</div>`
}));
urls.push('/stations/');

const freqList = [...byFreq.keys()].sort((a,b)=>a-b);
write('frequencies/index.html', page({
  title: 'All Shortwave Frequencies | ShortwaveHQ',
  desc: `Browse all ${freqList.length} active shortwave frequencies with the stations broadcasting on each.`,
  canonical: `${SITE}/frequencies/`, h1: 'All Shortwave Frequencies',
  sub: `${freqList.length} frequencies logged`, jsonld: null,
  main: `<div class="links">${freqList.map(f=>`<a href="/frequency/${f}/">${f} kHz</a>`).join('')}</div>`
}));
urls.push('/frequencies/');

// ── sitemap.xml + robots.txt ──────────────────────────────────────
// Homepage carries live daily data -> lastmod = today. Schedule/station/
// frequency pages are evergreen -> lastmod = when SCH last changed (honest).
const lastmodFor = u => (u === '/') ? today : SCHED_DATE;
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${[...new Set(urls)].map(u=>`<url><loc>${SITE}${u}</loc><lastmod>${lastmodFor(u)}</lastmod></url>`).join('\n')}
</urlset>`;
write('sitemap.xml', sitemap);
write('robots.txt', `User-agent: *\nAllow: /\nSitemap: ${SITE}/sitemap.xml\n`);

console.log(`Done. ${byStation.size} station pages, ${byFreq.size} frequency pages, ${[...new Set(urls)].length} URLs in sitemap.`);
console.log(`Output: ${OUT}`);
